/*
 * Copyright 2008 The Android Open Source Project
 */
#ifndef LIBFFI_H

#define MIPS
#include "../src/mips/ffitarget.h"
#include "../include/ffi_real.h"

#endif

/*
 * Copyright 2008 The Android Open Source Project
 */
#ifndef LIBFFI_H

#define X86 1
#define CONF_HAVE_LONG_DOUBLE 1

#include "../src/x86/ffitarget.h"
#include "../include/ffi_real.h"

#endif
